<!DOCTYPE html>

<?php session_start(); ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>
  <body>
<center>
    <?php

    if (isset($_SESSION["admin_email"])) {
      $name = $_SESSION["name"];

      $email = $_SESSION["admin_email"];

      $photo = $_SESSION['admin_pic'];



     ?>
     <center>

<h2 style="font-family:sans-serif;">Hello


  <b style="color:red;font-size:16pt;text-decoration:underline;"><?php echo $name; ?></b>


   you are successfully authenticated</h2>
   <br><br>

 </center>
<div class="col-lg-12" style="border:1px solid black;">



<h3>Name : <?php echo $name; ?></h3>

<h3>Image : <img src="<?php echo $photo; ?>" alt="" style="border-radius:100px;"> </h3>

<h3>email : <?php echo $email; ?> </h3>

</div>

<?php } ?>


<a href="userinfo.php?l=logout" class="btn btn-lg btn-primary" style="margin-top:100px;">Log out</a>



</center>
</body>
</html>


<?php


if (isset($_GET['l'])) {

      session_destroy();
      header("location:http://localhost/missnorah/frontend.php");


}





 ?>
