<?php

    session_start();
    require_once('includes/hybridauth/src/autoload.php');

    if(isset($_SESSION["admin_email"]))
    {
        header("location:http://localhost/missnorah/userinfo.php");
    }


// we are using these built in functions of composer

    use Hybridauth\Exception\Exception;
    use Hybridauth\Hybridauth;
    use Hybridauth\HttpClient;

    // this is the end of built in function of composer

    if($_GET["key"] == "google")
    {
        $provider = $_GET["key"];
        $config = [
            'callback' => "http://localhost/missnorah/authentication/backend.php?key=$provider",
            'providers' => [
                'Google' => [
                    'enabled' => true,
                    'keys' => [
                        'id' => '156725802010-rag8dsgncoc7ec2b7j42nj85hp4chmhj.apps.googleusercontent.com',
                        'secret' => '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',
                    ]
                ]
            ]
        ];
    }

    else
    {
        HttpClient\Util::redirect('http://localhost/missnorah/frontend.php');
    }

    try
    {

      // buit it functions of composer php

        $hybridauth = new Hybridauth($config);

        $hybridauth->authenticate(ucfirst($provider));

        $adapters = $hybridauth->getConnectedAdapters();

        $userInfo = $adapters[ucfirst($provider)]->getUserProfile();

      // variables which contain user data

        $email = $userInfo->email;
        $user_avatar = $userInfo->photoURL;
        $fullname = $userInfo->firstName." ".$userInfo->lastName;



        $_SESSION["name"] = $fullname;
        $_SESSION["admin_email"] = $email;
        $_SESSION['admin_pic'] = $user_avatar;

        /**
        * Redirects user to home page after successful login attemp
        */
        HttpClient\Util::redirect('http://localhost/missnorah/userinfo.php');

    }
    catch (Exception $ee)
    {
        echo $ee->getMessage();
    }
?>
